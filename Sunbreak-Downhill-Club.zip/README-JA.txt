Sunbreak: Downhill Club

ゲーム本体・ソースコード・テスト・設計書を同梱しています。

【PCで起動】
1. ZIPを展開します。
2. Pythonがある場合、展開したフォルダ内で次を実行します。
   python -m http.server 8000 --directory dist
3. ブラウザで http://localhost:8000 を開きます。
※ HTMLの直接ダブルクリックではJavaScriptモジュールを読み込めない場合があります。

【Web公開】
dist内の全ファイルを同じ階層のまま静的ホスティングにアップロードします。
iPhoneでは公開URLをSafariで開いてください。

【操作】
自動ペダル・着地アシストは標準で有効です。
左右/A D: ステア、Space: ジャンプ、F: 技、Q/E: 技選択
Shift: ブースト、S/下: ブレーキ、Escape: 一時停止
手動空中姿勢: I/K（着地アシストOFF時）
スマホ: 画面上の操作ボタン

【開発】
npm ci
npm run dev
npm test

【確認範囲】
物理・衝突・道路・脚の連動などの自動テスト済み。
iPhone実機・GPUでの最終実走検証は未完了です。
詳細はDESIGN_AND_QA.mdを参照してください。
