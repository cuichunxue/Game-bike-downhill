import assert from 'node:assert/strict';
import {makeRacer,stepRacer,TRICKS,startTrick,raceOrder,solveKnee,aiInput,playerInput} from '../dist/physics.mjs';
const flat={length:3600,width:12.5,sample:()=>({curvature:0})};
let passes=0;function test(name,fn){fn();passes++;console.log('PASS',name)}
test('8 tricks complete and land',()=>{for(let i=0;i<8;i++){const r=makeRacer('YOU');r.y=.5;r.vy=12;assert(startTrick(r,i));for(let n=1;n<400;n++)stepRacer(r,{},1/120,flat,[],[],n/120);assert(r.score>=450,TRICKS[i]);assert.equal(r.crash,0);}});
test('incomplete trick crashes on landing',()=>{const r=makeRacer('YOU');r.y=.3;r.vy=-5;startTrick(r,0);const e=stepRacer(r,{},.1,flat,[],[],.1);assert(e.includes('fall'));assert(r.speed<15)});
test('pitch and roll affect landing',()=>{const r=makeRacer('YOU');r.y=.02;r.vy=-6;r.roll=.9;assert(stepRacer(r,{},1/120,flat,[],[],1).includes('fall'))});
test('rock impact is swept and reduces speed',()=>{const r=makeRacer('YOU');r.speed=40;r.t=.1;const rock={t:.1001,lane:0};const e=stepRacer(r,{},1/30,flat,[rock],[],1);assert(e.includes('rock:0'));assert(r.speed<20);assert(r.crash>0)});
test('jump clears rock',()=>{const r=makeRacer('YOU');r.y=2;r.t=.1;assert(!stepRacer(r,{},1/120,flat,[{t:.1,lane:0}],[],1).includes('rock:0'))});
test('boost remains at or below 165km/h',()=>{const r=makeRacer('YOU');for(let n=0;n<1000;n++){r.boost=100;stepRacer(r,{boost:true},1/120,flat,[],[],n/120);assert(r.speed*3.6<=165)}});
test('inside line covers more progress than outside',()=>{const tr={...flat,sample:()=>({curvature:.01})},a=makeRacer('A','player',.7),b=makeRacer('B','player',-.7);for(let i=0;i<100;i++){stepRacer(a,{},1/120,tr,[],[],i/120);stepRacer(b,{},1/120,tr,[],[],i/120)}assert(a.t>b.t)});
test('all three AI finish without warping',()=>{const field=['attack','defend','style'].map(x=>makeRacer(x,x));for(let i=1;i<180*120;i++){for(const r of field){const prev=r.t;stepRacer(r,aiInput(r,field,flat,[],[],i/120),1/120,flat,[],[],i/120);assert(r.t-prev<.001)}}assert(field.every(r=>r.finish!==null));console.log('AI times',field.map(r=>r.finish.toFixed(2)).join(', '))});
test('finish order uses crossing time',()=>{const a=makeRacer('A'),b=makeRacer('B');a.finish=100;b.finish=99;a.t=b.t=1;assert.equal(raceOrder([a,b])[0].name,'B')});
test('leg IK preserves segment length through a crank cycle',()=>{for(let i=0;i<360;i++){const a=i*Math.PI/180,hip=[.2,1.67,-.38],foot=[.2,.97+Math.cos(a)*.3,-.19+Math.sin(a)*.3],k=solveKnee(hip,foot);assert(Math.abs(Math.hypot(k[1]-hip[1],k[2]-hip[2])-.67)<1e-6);assert(Math.abs(Math.hypot(k[1]-foot[1],k[2]-foot[2])-.67)<1e-6)}});
test('120Hz integration independent of display refresh',()=>{for(const rate of [30,60,120]){const r=makeRacer('YOU');for(let f=0;f<rate*10;f++)for(let sub=0;sub<120/rate;sub++)stepRacer(r,{pedal:true},1/120,flat,[],[],f/rate);assert(r.t>.1&&r.t<.12)}});
test('held pedal does not pitch rider during assisted jump',()=>{const r=makeRacer('YOU');let fell=false;for(let i=0;i<360;i++){const input=playerInput({pedal:1,left:0,right:0,jump:i===0},r);const events=stepRacer(r,input,1/120,flat,[],[],i/120);fell ||= events.includes('fall');}assert(!fell);assert.equal(r.pitch,0);assert(r.speed>0)});
test('manual pitch remains independent of pedal and assisted steering',()=>{const r=makeRacer('YOU');r.y=2;assert.equal(playerInput({pedal:1,left:0,right:0},r,{assist:false}).pitch,0);assert.equal(playerInput({pitchBack:1,left:0,right:0},r,{assist:false}).pitch,1);assert.equal(playerInput({left:0,right:1},r).airRoll,.3)});
console.log(passes+' checks passed');
